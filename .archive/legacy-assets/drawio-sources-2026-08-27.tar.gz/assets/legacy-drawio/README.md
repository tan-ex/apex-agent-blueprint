# Legacy Draw.io Assets

These files are historical examples retained for reference. Current APEX agents
do not generate, validate, or support Draw.io files.

Use the `python-diagrams` skill for new diagrams. It produces reproducible
Python source with PNG and SVG renders.
